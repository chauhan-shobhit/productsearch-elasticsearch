package com.shobhit.elasticsearch.SearchServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchServicesApplication.class, args);
	}

}
